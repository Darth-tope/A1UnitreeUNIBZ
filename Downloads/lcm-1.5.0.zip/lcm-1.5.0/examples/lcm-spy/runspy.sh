#!/bin/sh

export CLASSPATH=my_types.jar
lcm-spy

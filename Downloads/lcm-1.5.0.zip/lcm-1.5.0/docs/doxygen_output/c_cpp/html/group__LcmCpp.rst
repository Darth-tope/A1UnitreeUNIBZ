C++ API
=======

This is a placeholder to trick sphinx so that it will create links to an external file that will
exist later.
